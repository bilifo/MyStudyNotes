/*
 * Copyright 2009 Cedric Priscal
 * 
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 * 
 * http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License. 
 */

package android.serialport;

import java.io.File;
import java.io.FileDescriptor;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.Arrays;
import android.util.Log;

public class SerialPort {

	private static final String TAG = "SerialPort";

	/*
	 * Do not remove or rename the field mFd: it is used by native method close();
	 */
	private FileDescriptor mFd;
	private static FileInputStream mFileInputStream;
	private static FileOutputStream mFileOutputStream;
	public static  ArrayList<byte[]> list=new ArrayList<byte[]>();
	private static ReadThread mreadthread;
	private static boolean flag=false;//清空list开关,false为有数据，true为无数据


	public SerialPort(File device, int baudrate) throws SecurityException, IOException {

		/* Check access permission */
		if (!device.canRead() || !device.canWrite()) {
			try {
				/* Missing read/write permission, trying to chmod the file */
				Process su;
				su = Runtime.getRuntime().exec("/system/xbin/su");
				String cmd = "chmod 777 " + device.getAbsolutePath() + "\n"
						+ "exit\n";
				/*String cmd = "chmod 777 /dev/s3c_serial0" + "\n"
				+ "exit\n";*/
				su.getOutputStream().write(cmd.getBytes());
				if ((su.waitFor() != 0) || !device.canRead()
						|| !device.canWrite()) {
					throw new SecurityException();
				}
			} catch (Exception e) {
				e.printStackTrace();
				throw new SecurityException();
			}
		}

		mFd = open(device.getAbsolutePath(), baudrate);
		if (mFd == null) {
			Log.e(TAG, "native open returns null");
			throw new IOException();
		}
		mFileInputStream = new FileInputStream(mFd);
		mFileOutputStream = new FileOutputStream(mFd);
//		mFileInputStream.reset();
		//开启接收线程
				mreadthread = new ReadThread();
				mreadthread.start();

	}

	// Getters and setters
	public InputStream getInputStream() {
		return mFileInputStream;
	}

	public OutputStream getOutputStream() {
		return mFileOutputStream;
	}
	/**
	 * 发送
	 * @param cmd
	 * @throws Exception
	 */
	public static void send(byte[] cmd) throws Exception {
//		mFileOutputStream = (FileOutputStream) getOutputStream();
		mFileOutputStream.write(cmd);
		mFileOutputStream.flush();
	}
	/**
	 * 接收
	 * @return
	 */
	public ArrayList<byte[]> getBuffer(){
		flag=true;
		return list;	
	}
	/**
	 * 查看是否有接收的数据
	 */
	public boolean select(){
		return flag;
	}
	
	/**
	 * 接收，当收到“0xf5”时，就会结束。单开一个线程来进行接收才有效果。
	 */
	private class ReadThread extends Thread {
		@Override
		public void run() {
			super.run();
			mFileInputStream = (FileInputStream)getInputStream();
			byte[] temp = null;
			while (!isInterrupted()) {
				temp = null;
				if (mFileInputStream != null) {
					try {
						int i = 0;
//						int bb;
						byte bb;
	// 为什么要把它分成"byte[] temp=null;"和"temp=new byte[80];"，因为这样才能使数组每次清空数据
						temp = new byte[1024];
//						do {// 一个字节一个字节的读
//							bb =  mFileInputStream.read();
//							temp[i] = (byte)bb;
//							i++;
//						} while (bb!=-1); // 保证结束符为-1	

//						while(true){
//							bb =  mFileInputStream.read();
//							if(bb==-1) break;
//							temp[i] = (byte)bb;
//							i++;
//						}
						do {// 一个字节一个字节的读
						bb =  (byte)mFileInputStream.read();
						temp[i] = bb;
						i++;
					} while (bb!=(byte)0xf5); // 保证结束符为-1	
						if(flag==true){//清空ArrayList集合，释放资源
							list.clear();
						}//用ArrayList<byte[]>来存放byte数组，这样能缓存接收的数据
							list.add(Arrays.copyOf(temp, i));//用Arrays.copyOf()来传递，可以确定这个数组的具体长度
							flag=false;//把标志位改回不清空状态
					} catch (IOException e) {
						e.printStackTrace();
					}
				}
			}
		}
	}
	
	// 16进制字节（byte）转字符串
	public static String bytesToHexString(byte[] src) {
		StringBuilder stringBuilder = new StringBuilder("");
		if (src == null || src.length <= 0) {
			return null;
		}
		for (int i = 0; i < src.length; i++) {
			int v = src[i] & 0xFF;
			String hv = Integer.toHexString(v);
			if (hv.length() < 2) {
				stringBuilder.append(0);
			}
			stringBuilder.append(hv);
		}
		return stringBuilder.toString();
	}

	public static byte[] hexStringToBytes(String hexString) {
		if (hexString == null || hexString.equals("")) {
			return null;
		}
		hexString = hexString.toUpperCase();
		int length = hexString.length() / 2;
		char[] hexChars = hexString.toCharArray();
		byte[] d = new byte[length];
		for (int i = 0; i < length; i++) {
			int pos = i * 2;
			d[i] = (byte) (charToByte(hexChars[pos]) << 4 | charToByte(hexChars[pos + 1]));
		}
		return d;
	}

	private static byte charToByte(char c) {
		return (byte) "0123456789ABCDEF".indexOf(c);
	}

	// JNI
	private native static FileDescriptor open(String path, int baudrate);
	public native void close();
	static {
		System.loadLibrary("serial_port");
	}
}
