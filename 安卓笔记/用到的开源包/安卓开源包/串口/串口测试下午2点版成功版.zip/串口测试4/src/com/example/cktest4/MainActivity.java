package com.example.cktest4;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;

import android.app.Activity;
import android.os.Bundle;
import android.serialport.SerialPort;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends Activity{
	TextView tv;
	EditText ed;
	SerialPort sp;
	FileOutputStream fos;
	FileOutputStream fis;
	byte[] buffer;
//	ZigbeeAPI zapi=new ZigbeeAPI();
	@Override
	protected void onCreate(Bundle savedInstanceState)  {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);
		ed=(EditText) findViewById(R.id.ed);
		tv=(TextView) findViewById(R.id.textView1);
		try {
			sp=new SerialPort(new File("/dev/ttySAC3"), 38400);
		} catch (SecurityException | IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}
	
	public void accept(View view)throws Exception{
		ArrayList<byte[]> list;
//		byte[] butt=null;
		if(sp.select()==false){
		list=sp.getBuffer();
		for(int i=0;i<list.size();i++){
			System.out.println(SerialPort.bytesToHexString(list.get(i)));
		}
		}
	}
	
	
	public void send(View view) throws Exception{
		String src=ed.getText().toString().trim();
		System.out.println("src为："+src);
		SerialPort.send(SerialPort.hexStringToBytes(src));
		System.out.println(sp.select());
	}
		
}
