/** Automatically generated file. DO NOT MODIFY */
package com.example.cktest4;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}