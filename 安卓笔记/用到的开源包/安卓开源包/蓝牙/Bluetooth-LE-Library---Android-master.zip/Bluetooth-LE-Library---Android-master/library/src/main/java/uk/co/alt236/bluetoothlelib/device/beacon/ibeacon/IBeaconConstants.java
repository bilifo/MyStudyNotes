package uk.co.alt236.bluetoothlelib.device.beacon.ibeacon;

/**
 *
 */
public class IBeaconConstants {
    public static final byte[] MANUFACTURER_DATA_IBEACON_PREFIX = {0x4C, 0x00, 0x02, 0x15};

}
