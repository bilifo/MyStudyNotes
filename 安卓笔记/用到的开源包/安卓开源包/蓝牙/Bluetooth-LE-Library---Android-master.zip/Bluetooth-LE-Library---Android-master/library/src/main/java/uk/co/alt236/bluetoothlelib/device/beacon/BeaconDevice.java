package uk.co.alt236.bluetoothlelib.device.beacon;

/**
 *
 */
public interface BeaconDevice {
    BeaconType getBeaconType();
}
