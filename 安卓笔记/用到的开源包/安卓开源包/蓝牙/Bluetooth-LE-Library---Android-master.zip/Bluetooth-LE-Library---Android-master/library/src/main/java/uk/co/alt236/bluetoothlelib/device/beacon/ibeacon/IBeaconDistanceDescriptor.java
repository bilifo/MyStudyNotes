package uk.co.alt236.bluetoothlelib.device.beacon.ibeacon;

public enum IBeaconDistanceDescriptor {
    IMMEDIATE,
    NEAR,
    FAR,
    UNKNOWN,
}
