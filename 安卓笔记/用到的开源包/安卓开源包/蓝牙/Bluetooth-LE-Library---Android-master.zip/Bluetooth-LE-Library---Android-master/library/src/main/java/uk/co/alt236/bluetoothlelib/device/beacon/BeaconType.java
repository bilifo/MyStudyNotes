package uk.co.alt236.bluetoothlelib.device.beacon;

/**
 *
 */
public enum BeaconType {
    NOT_A_BEACON,
    IBEACON,
}
